"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
let security = {
    sqlHost: '',
    sqlPassword: '',
    sqlDB: "",
    jwt_password: '',
    adminMailPassword: '',
};
exports.security = security;
