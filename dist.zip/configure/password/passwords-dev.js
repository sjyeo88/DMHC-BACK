"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
let security = {
    sqlHost: '13.125.58.139',
    sqlPassword: '!dutkak3',
    sqlDB: "DMHC",
    jwt_password: '!dutjdwnssla11',
    adminMailPassword: 'kusmilab1!',
};
exports.security = security;
