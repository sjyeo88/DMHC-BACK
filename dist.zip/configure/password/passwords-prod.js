"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
let security = {
    sqlHost: 'db-vol',
    sqlPassword: '!dutkak3',
    sqlDB: "DMHC",
    jwt_password: '!dutjdwnssla11',
    adminMailPassword: 'kusmilab1!',
};
exports.security = security;
