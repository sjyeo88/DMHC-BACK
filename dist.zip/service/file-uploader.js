"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
let Q = require('q');
class FileUploader {
}
exports.FileUploader = FileUploader;
